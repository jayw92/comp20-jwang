//Init
var express = require('express');
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'jay-score');

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI ||
   process.env.MONGOHQ_URL ||
   'mongodb://user:1234@ds041337.mongolab.com:41337/heroku_app15068501';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
   console.log(error);
   db = databaseConnection;
});

app.all('/', function (req, res) {
   res.header("Access-Control-Allow-Origin", "*");
   res.header("Access-Control-Allow-Headers", "X-Requested-With");
});

app.get('/', function (req, res) {
   res.set('Content-Type', 'text/html');
   mongo.Db.connect(mongoUri, function(err, db){
      db.collection('allscores', function(er, collection) {
        collection.find().sort({score:-1}).limit(10).toArray( function(er, results) {
          res.send(results);
        })
      });
    });
   res.send('<p>....</p>');
});

app.get('/usersearch', function (req, res) {
   res.set('Content-Type', 'text/html');
   res.send('<form id="form1" name="form1" method="get" action="/highscores.json"><p><label>Search:</label><input name="title" type="text" id="input" maxlength="50" /> </p><p><input type="submit" name="sumbit" id="submit" value="Submit" /></p></form>');
});

app.get('/highscores.json', function(request, response) {
  res.set('Content-Type', 'text/json');
  var game_title = request.query.game_title;
  if (game_title) {
    mongo.Db.connect(mongoUri, function(err, db){
      db.collection('highscores', function(er, collection) {
        collection.find({ game_title: game_title }).sort({score:-1}).limit(10).toArray( function(er, results) {
          res.send(results);
        })
      });
    });
  } else {
    res.send([])
  }
});

app.post('/submit.json', function(req, res) {
   var scoreN = parseInt(req.body.score);
   var usr = req.body.username;
   var date = new Date();
   var results = { game_title: req.body.game_title, username: usr, score: scoreN, created_at: date }
   collection.
});

app.listen(process.env.PORT || 5000);